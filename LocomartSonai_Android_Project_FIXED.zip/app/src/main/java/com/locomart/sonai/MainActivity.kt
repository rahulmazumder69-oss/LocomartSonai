package com.locomart.sonai
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Product(val name:String,val price:Int,val category:String)

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{Locomart()}}
}
@Composable fun Locomart(){
 val products=listOf(Product("Rice 5 kg",320,"Staples"),Product("Atta 5 kg",280,"Staples"),
 Product("Mustard Oil 1 L",160,"Oil"),Product("Tea 250 g",120,"Beverages"),
 Product("Sugar 1 kg",48,"Staples"),Product("Salt 1 kg",25,"Staples"))
 var cart by remember{mutableStateOf(listOf<Product>())}; var open by remember{mutableStateOf(false)}
 MaterialTheme{Scaffold(topBar={TopAppBar(title={Text("Locomart Sonai")},actions={TextButton({open=true}){Text("Cart (${cart.size})")}})}){p->
  if(open) Column(Modifier.padding(p).padding(20.dp)){Text("Your Cart",style=MaterialTheme.typography.headlineMedium)
   cart.forEach{Text("• ${it.name} — ₹${it.price}")};val total=cart.sumOf{it.price}+if(cart.isEmpty())0 else 30
   Spacer(Modifier.height(12.dp));Text("Total: ₹$total",style=MaterialTheme.typography.titleLarge)
   Button({}){Text("Place Order — COD / UPI")};TextButton({open=false}){Text("Back")}
  } else LazyColumn(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   item{Text("Grocery delivered to your door",style=MaterialTheme.typography.headlineSmall);Text("Sonai • 10 km • COD + UPI")}
   items(products){x->Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween){
    Column{Text(x.name);Text("₹${x.price}")};Button({cart=cart+x}){Text("Add")}
   }}}
  }
 }}
}
