Locomart Sonai Android project.

Build configuration fixed for Java/Kotlin JVM target 17 and Kotlin 2.0 Compose compiler plugin.

Includes catalogue, cart, COD/UPI checkout placeholder, Sonai 10 km service messaging.

Production release still needs real backend, payment integration, authentication, admin panel, notifications, maps/radius validation, signing and Play Console setup.
