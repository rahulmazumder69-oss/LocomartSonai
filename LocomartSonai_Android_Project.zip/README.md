Locomart Sonai Android project.
Includes catalogue, cart, COD/UPI checkout placeholder, Sonai 10 km service messaging.
Production release still needs real backend, payment integration, authentication, admin panel, notifications, maps/radius validation, signing and Play Console setup.
